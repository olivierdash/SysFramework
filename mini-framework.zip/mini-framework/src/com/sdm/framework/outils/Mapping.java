package com.sdm.framework.outils;

import java.lang.reflect.Method;

public class Mapping {
    private Class<?> controllerClass;
    private Method method;

    public Mapping(Class<?> controllerClass, Method method) {
        this.controllerClass = controllerClass;
        this.method = method;
    }

    public Class<?> getControllerClass() {
        return controllerClass;
    }

    public Method getMethod() {
        return method;
    }
}