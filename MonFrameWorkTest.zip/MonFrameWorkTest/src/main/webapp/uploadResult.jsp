<%@ page contentType="text/html;charset=UTF-8" %>
<h1>Salut ${personne.nom}</h1>
<p>Fichier : ${personne.photo.nomFichier}</p>
<p>Type : ${personne.photo.type}</p>
<p>Taille : ${personne.photo.contenu.length} octets</p>
<p>Enregistre dans : ${personne.photo.cheminSauvegarde}</p>
